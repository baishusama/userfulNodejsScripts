module.exports = {
    tabWidth: 4,
    proseWrap: 'always',
    printWidth: 120,
    singleQuote: true
};
