<template>
    <div
        class="current-button"
        static-attr-chinese="静态html属性"
        static-attr-english="'no need'"
        :bind-attr-chinese="'动态html属性'"
    >
        静态html内容
        <div>动态html内容前 {{ cancelText ? '双要替换的' : $t('双向绑定中不需要替换的') }} dynamic html after</div>
    </div>
</template>
<script>
export default {
    data() {
        return {
            companies: [],
            showClose: true
        };
    },
    async created() {
        if (!window.WeixinJSBridge || !WeixinJSBridge.invoke) {
            document.addEventListener('WeixinJSBridgeReady', this.ready, false);
        } else {
            this.ready();
        }
        let loading = this.$loading('正在加载，请稍候');
        try {
            let data = await this.get('/user/company/all');
            this.companies = data.result;
        } catch (e) {
            console.log(e);
        } finally {
            loading.close();
        }
    },
    watch: {},
    computed: {
        companiesShow() {
            let companies = this.deepClone(this.companies);
            if (this.activeCompanyIndex == -1) {
                return companies;
            }
            let activeCompany = companies.splice(this.activeCompanyIndex, 1)[0];
            companies.unshift(activeCompany);
            return companies.filter(company => company.auth);
        },
        activeCompany() {
            return this.companies.$get(this.activeCompanyIndex);
        },
        activeCompanyIndex() {
            let companyId = quser.$get('company', 'id');
            if (companyId) {
                return this.companies.findIndex(company => company.companyId == companyId);
            } else {
                return -1;
            }
        }
    },

    methods: {
        ready() {
            if (window.__wxjs_environment === 'miniprogram') {
                this.showClose = false;
            }
        },
        companyAuth() {
            this.$router.push({ name: 'companyAuthType' });
        },
        joinCompany() {
            this.$router.push({ name: 'joinCompanyNew' });
        },
        toBack() {
            this.$router.back();
        },
        async switchCompany(company) {
            this.$modal({
                visible: false,
                showCancel: true,
                content: '切换后，可使用该企业下的分类发起签约，确定切换？',
                okfn: async () => {
                    try {
                        await this.postForm('/company/active', { id: company.companyId });
                        let data = await this.get('/user/quser');
                        window.quser = data;
                        this.toBack();
                    } catch (error) {
                        console.log(errpr);
                    }
                },
                cancel() {}
            });
        }
    }
};
</script>
<style scoped lang="less">
*,
*:before,
*:after {
    box-sizing: border-box;
}
@import (reference) '../extend.less';

svg {
    margin-left: 4px;
}
.has-join-info {
    margin: 9px 20px;
    height: 17px;
    line-height: 17px;
    font-size: 12px;
    font-family: PingFangSC-Regular;
    color: #7f8997;
}

.company {
    background: white;
    .company-inner-wrapper {
        margin-left: 20px;
        padding: 20px 40px 20px 0;
        position: relative;
    }
    &:not(:last-child) .company-inner-wrapper {
        border-bottom: 1px solid #ececec;
    }
    &:active .company-inner-wrapper {
        background: #f5f5f5;
    }

    .right-icon {
        right: 20px;
        font-size: 12px;
    }
    .current-button {
        color: #f0a128;
    }
    .switch-button {
        border-radius: 3px;
        border: 1px solid #c1c6cd;
        padding: 0 7px;
        height: 24px;
        line-height: 24px;
        font-size: 12px;
        font-family: PingFangSC-Regular;
        color: #4c596e;
    }

    .title {
        font-size: 16px;
        color: #383838;
        line-height: 20px;
        span {
            max-width: e('calc(100% - 60px)');
            vertical-align: middle;
            margin-top: -4px;
            display: inline-block;
        }
        i {
            font-size: 45px;
            line-height: 0px;
            color: #c0c0c0;
            vertical-align: middle;
        }
    }
    .sub-title {
        font-size: 12px;
        color: #7f8997;
        line-height: 20px;
    }

    &.active-company {
        margin-top: 10px;

        .company-inner-wrapper {
            border-bottom: 0;
        }
        .title span {
            height: 22px;
            line-height: 22px;
            font-size: 16px;
            font-weight: bold;
            font-family: PingFangSC-Medium;
            color: #001330;
        }
    }
}
.content {
    &:extend(.main-page);
    padding-top: 40px;
}
header {
    &:extend(.header all);
}
</style>
