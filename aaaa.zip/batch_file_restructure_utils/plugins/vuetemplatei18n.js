const compiler = require('vue-template-compiler');
const vuejsi18n = require('./vuejsi18n');
module.exports = vuetemplatei18n;

function vuetemplatei18n(templateContent) {
    let { ast } = compiler.compile(templateContent, {
        outputSourceRange: true
    });
    let needTransform = [];
    analysisAst(ast, needTransform);
    let transformedContent = '';
    for (let i = 0; i < needTransform.length; i++) {
        let preNode = needTransform[i - 1] || {
            end: 0
        };
        let curNode = needTransform[i];
        let needTransformString = templateContent.slice(curNode.start, curNode.end);
        let visibleStringStart = needTransformString.search(/\S/);
        let visibleStringEnd =
            needTransformString.length -
            needTransformString
                .split('')
                .reverse()
                .join('')
                .search(/\S/);
        let transformedString = '';
        let isNeedTransform = /[\u4e00-\u9fa5]/;
        switch (curNode.type) {
            case 'htmlAttr':
                if (!isNeedTransform.test(needTransformString)) {
                    transformedString = needTransformString;
                } else {
                    transformedString = `${needTransformString.slice(
                        0,
                        visibleStringStart
                    )}:${needTransformString
                        .slice(visibleStringStart, visibleStringEnd)
                        .replace(curNode.value, `"$t('${curNode.value.slice(1, -1)}')"`)}${needTransformString.slice(
                        visibleStringEnd
                    )}`;
                }
                break;
            case 'htmlContent':
                if (!isNeedTransform.test(needTransformString)) {
                    transformedString = needTransformString;
                } else {
                    transformedString = `${needTransformString.slice(
                        0,
                        visibleStringStart
                    )}{{$t('${needTransformString.slice(
                        visibleStringStart,
                        visibleStringEnd
                    )}')}}${needTransformString.slice(visibleStringEnd)}`;
                }
                break;
            case 'htmlDynamicAttr':
                transformedString = `${needTransformString.slice(0, visibleStringStart)}${needTransformString
                    .slice(visibleStringStart, visibleStringEnd)
                    .replace(curNode.value, vuejsi18n(curNode.value))}${needTransformString.slice(visibleStringEnd)}`;
                break;
            case 'htmlDynamicContent':
                transformedString = `${needTransformString.slice(0, visibleStringStart)}${curNode.tokens
                    .filter(token => {
                        if (typeof token == 'string') {
                            return !!token.replace(/\s/g, '');
                        } else {
                            return true;
                        }
                    })
                    .map(token => {
                        if (typeof token == 'string') {
                            if (!isNeedTransform.test(token)) {
                                return `${token.trim()}`;
                            } else {
                                return `{{ $t('${token.trim()}') }}`;
                            }
                        } else {
                            return `{{ ${vuejsi18n(token['@binding'])} }}`;
                        }
                    })
                    .join(' ')}${needTransformString.slice(visibleStringEnd)}`;
                break;
            default:
                throw new Error('没有类型');
                break;
        }
        if (i != needTransform.length - 1) {
            transformedContent += `${templateContent.slice(preNode.end, curNode.start)}${transformedString}`;
        } else {
            transformedContent += `${templateContent.slice(
                preNode.end,
                curNode.start
            )}${transformedString}${templateContent.slice(curNode.end)}`;
        }
    }
    return transformedContent;
}
function analysisAst(ast, array) {
    ast.attrs &&
        ast.attrs.map(attr => {
            let start = attr.start + 1;
            let end = attr.end + 1;
            let type = '';
            if (attr.dynamic === undefined) {
                type = 'htmlAttr';
            } else {
                type = 'htmlDynamicAttr';
            }
            array.push({
                start: start,
                end: end,
                value: attr.value,
                type
            });
        });
    //type 为 1 表示是普通元素，为 2 表示是表达式，为 3 表示是纯文本
    if (ast.type == 3) {
        let start = ast.start + 1;
        let end = ast.end + 1;
        array.push({
            start,
            end,
            type: 'htmlContent'
        });
    }
    if (ast.type == 2) {
        let start = ast.start + 1;
        let end = ast.end + 1;
        array.push({
            start,
            end,
            tokens: ast.tokens,
            type: 'htmlDynamicContent'
        });
    }
    if (ast.children) {
        ast.children.map(childNode => {
            if (!childNode) {
                return;
            }
            analysisAst(childNode, array);
        });
    }
}
